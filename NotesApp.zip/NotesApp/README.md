# Android-Kotlin-Room-Notes-App

## Made with 100% Kotlin and Material Android Compoents

Use with Android Studio 3.5 or higher
