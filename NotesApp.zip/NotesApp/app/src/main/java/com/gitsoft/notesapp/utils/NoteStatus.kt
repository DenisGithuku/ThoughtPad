package com.gitsoft.notesapp.utils

enum class NoteStatus {
    EMPTY,
    OCCUPIED
}