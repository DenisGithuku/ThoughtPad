package com.gitsoft.notesapp.datasource

class NotesLocalDataSource {

}